/*
 * Python object definition of the sequence and iterator object of file entries
 *
 * Copyright (C) 2008-2017, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This software is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this software.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <common.h>
#include <types.h>

#if defined( HAVE_STDLIB_H ) || defined( HAVE_WINAPI )
#include <stdlib.h>
#endif

#include "pyewf_file_entries.h"
#include "pyewf_file_entry.h"
#include "pyewf_libcerror.h"
#include "pyewf_libewf.h"
#include "pyewf_python.h"

PySequenceMethods pyewf_file_entries_sequence_methods = {
	/* sq_length */
	(lenfunc) pyewf_file_entries_len,
	/* sq_concat */
	0,
	/* sq_repeat */
	0,
	/* sq_item */
	(ssizeargfunc) pyewf_file_entries_getitem,
	/* sq_slice */
	0,
	/* sq_ass_item */
	0,
	/* sq_ass_slice */
	0,
	/* sq_contains */
	0,
	/* sq_inplace_concat */
	0,
	/* sq_inplace_repeat */
	0
};

PyTypeObject pyewf_file_entries_type_object = {
	PyVarObject_HEAD_INIT( NULL, 0 )

	/* tp_name */
	"pyewf._file_entries",
	/* tp_basicsize */
	sizeof( pyewf_file_entries_t ),
	/* tp_itemsize */
	0,
	/* tp_dealloc */
	(destructor) pyewf_file_entries_free,
	/* tp_print */
	0,
	/* tp_getattr */
	0,
	/* tp_setattr */
	0,
	/* tp_compare */
	0,
	/* tp_repr */
	0,
	/* tp_as_number */
	0,
	/* tp_as_sequence */
	&pyewf_file_entries_sequence_methods,
	/* tp_as_mapping */
	0,
	/* tp_hash */
	0,
	/* tp_call */
	0,
	/* tp_str */
	0,
	/* tp_getattro */
	0,
	/* tp_setattro */
	0,
	/* tp_as_buffer */
	0,
	/* tp_flags */
	Py_TPFLAGS_DEFAULT | Py_TPFLAGS_HAVE_ITER,
	/* tp_doc */
	"pyewf internal sequence and iterator object of file entries",
	/* tp_traverse */
	0,
	/* tp_clear */
	0,
	/* tp_richcompare */
	0,
	/* tp_weaklistoffset */
	0,
	/* tp_iter */
	(getiterfunc) pyewf_file_entries_iter,
	/* tp_iternext */
	(iternextfunc) pyewf_file_entries_iternext,
	/* tp_methods */
	0,
	/* tp_members */
	0,
	/* tp_getset */
	0,
	/* tp_base */
	0,
	/* tp_dict */
	0,
	/* tp_descr_get */
	0,
	/* tp_descr_set */
	0,
	/* tp_dictoffset */
	0,
	/* tp_init */
	(initproc) pyewf_file_entries_init,
	/* tp_alloc */
	0,
	/* tp_new */
	0,
	/* tp_free */
	0,
	/* tp_is_gc */
	0,
	/* tp_bases */
	NULL,
	/* tp_mro */
	NULL,
	/* tp_cache */
	NULL,
	/* tp_subclasses */
	NULL,
	/* tp_weaklist */
	NULL,
	/* tp_del */
	0
};

/* Creates a new file entries object
 * Returns a Python object if successful or NULL on error
 */
PyObject *pyewf_file_entries_new(
           PyObject *parent_object,
           PyObject* (*get_item_by_index)(
                        PyObject *parent_object,
                        int index ),
           int number_of_items )
{
	pyewf_file_entries_t *file_entries_object = NULL;
	static char *function                     = "pyewf_file_entries_new";

	if( parent_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid parent object.",
		 function );

		return( NULL );
	}
	if( get_item_by_index == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid get item by index function.",
		 function );

		return( NULL );
	}
	/* Make sure the file entries values are initialized
	 */
	file_entries_object = PyObject_New(
	                       struct pyewf_file_entries,
	                       &pyewf_file_entries_type_object );

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_MemoryError,
		 "%s: unable to create file entries object.",
		 function );

		goto on_error;
	}
	if( pyewf_file_entries_init(
	     file_entries_object ) != 0 )
	{
		PyErr_Format(
		 PyExc_MemoryError,
		 "%s: unable to initialize file entries object.",
		 function );

		goto on_error;
	}
	file_entries_object->parent_object     = parent_object;
	file_entries_object->get_item_by_index = get_item_by_index;
	file_entries_object->number_of_items   = number_of_items;

	Py_IncRef(
	 (PyObject *) file_entries_object->parent_object );

	return( (PyObject *) file_entries_object );

on_error:
	if( file_entries_object != NULL )
	{
		Py_DecRef(
		 (PyObject *) file_entries_object );
	}
	return( NULL );
}

/* Intializes a file entries object
 * Returns 0 if successful or -1 on error
 */
int pyewf_file_entries_init(
     pyewf_file_entries_t *file_entries_object )
{
	static char *function = "pyewf_file_entries_init";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return( -1 );
	}
	/* Make sure the file entries values are initialized
	 */
	file_entries_object->parent_object     = NULL;
	file_entries_object->get_item_by_index = NULL;
	file_entries_object->current_index     = 0;
	file_entries_object->number_of_items   = 0;

	return( 0 );
}

/* Frees a file entries object
 */
void pyewf_file_entries_free(
      pyewf_file_entries_t *file_entries_object )
{
	struct _typeobject *ob_type = NULL;
	static char *function       = "pyewf_file_entries_free";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return;
	}
	ob_type = Py_TYPE(
	           file_entries_object );

	if( ob_type == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: missing ob_type.",
		 function );

		return;
	}
	if( ob_type->tp_free == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid ob_type - missing tp_free.",
		 function );

		return;
	}
	if( file_entries_object->parent_object != NULL )
	{
		Py_DecRef(
		 (PyObject *) file_entries_object->parent_object );
	}
	ob_type->tp_free(
	 (PyObject*) file_entries_object );
}

/* The file entries len() function
 */
Py_ssize_t pyewf_file_entries_len(
            pyewf_file_entries_t *file_entries_object )
{
	static char *function = "pyewf_file_entries_len";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return( -1 );
	}
	return( (Py_ssize_t) file_entries_object->number_of_items );
}

/* The file entries getitem() function
 */
PyObject *pyewf_file_entries_getitem(
           pyewf_file_entries_t *file_entries_object,
           Py_ssize_t item_index )
{
	PyObject *file_entry_object = NULL;
	static char *function       = "pyewf_file_entries_getitem";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return( NULL );
	}
	if( file_entries_object->get_item_by_index == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object - missing get item by index function.",
		 function );

		return( NULL );
	}
	if( file_entries_object->number_of_items < 0 )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object - invalid number of items.",
		 function );

		return( NULL );
	}
	if( ( item_index < 0 )
	 || ( item_index >= (Py_ssize_t) file_entries_object->number_of_items ) )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid invalid item index value out of bounds.",
		 function );

		return( NULL );
	}
	file_entry_object = file_entries_object->get_item_by_index(
	                     file_entries_object->parent_object,
	                     (int) item_index );

	return( file_entry_object );
}

/* The file entries iter() function
 */
PyObject *pyewf_file_entries_iter(
           pyewf_file_entries_t *file_entries_object )
{
	static char *function = "pyewf_file_entries_iter";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return( NULL );
	}
	Py_IncRef(
	 (PyObject *) file_entries_object );

	return( (PyObject *) file_entries_object );
}

/* The file entries iternext() function
 */
PyObject *pyewf_file_entries_iternext(
           pyewf_file_entries_t *file_entries_object )
{
	PyObject *file_entry_object = NULL;
	static char *function       = "pyewf_file_entries_iternext";

	if( file_entries_object == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object.",
		 function );

		return( NULL );
	}
	if( file_entries_object->get_item_by_index == NULL )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object - missing get item by index function.",
		 function );

		return( NULL );
	}
	if( file_entries_object->current_index < 0 )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object - invalid current index.",
		 function );

		return( NULL );
	}
	if( file_entries_object->number_of_items < 0 )
	{
		PyErr_Format(
		 PyExc_ValueError,
		 "%s: invalid file entries object - invalid number of items.",
		 function );

		return( NULL );
	}
	if( file_entries_object->current_index >= file_entries_object->number_of_items )
	{
		PyErr_SetNone(
		 PyExc_StopIteration );

		return( NULL );
	}
	file_entry_object = file_entries_object->get_item_by_index(
	                     file_entries_object->parent_object,
	                     file_entries_object->current_index );

	if( file_entry_object != NULL )
	{
		file_entries_object->current_index++;
	}
	return( file_entry_object );
}

