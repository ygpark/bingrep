
#include "stdafx.h"
#include "resource.h"
#include "DokanSSHProperty.h"

class CDokanSSHPropertyModule : public CAtlDllModuleT< CDokanSSHPropertyModule >
{
public :
	DECLARE_LIBID(LIBID_DokanSSHPropertyLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_DOKANSSHPROPERTY, "{A8503F95-4BB2-4EB6-800A-CE24B06B2314}")
};

