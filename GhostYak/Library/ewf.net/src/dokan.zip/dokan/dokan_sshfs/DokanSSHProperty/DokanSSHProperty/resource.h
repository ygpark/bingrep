//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DokanSSHProperty.rc
//
#define IDS_PROJNAME                    100
#define IDR_DOKANSSHPROPERTY            101
#define IDR_SSHPROPERTY                 102
#define IDD_SSH_PROPERTY                201
#define IDC_CHECK1                      201
#define IDC_W_READ                      201
#define IDC_CHECK2                      202
#define IDC_W_WRITE                     202
#define IDC_CHECK3                      203
#define IDC_W_EXEC                      203
#define IDC_CHECK4                      204
#define IDC_G_READ                      204
#define IDC_CHECK5                      205
#define IDC_G_WRITE                     205
#define IDC_CHECK6                      206
#define IDC_G_EXEC                      206
#define IDC_CHECK7                      207
#define IDC_O_READ                      207
#define IDC_CHECK8                      208
#define IDC_O_WRITE                     208
#define IDC_CHECK9                      209
#define IDC_O_EXEC                      209

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         210
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
