This project is a clone of the original Dokan (https://code.google.com/p/dokan/) source for libyal builds.

This project is primarily used for continous intergrations (CI) testing and legacy Dokan support.

For new projects it is highly encouraged to use [DokanY](https://github.com/dokan-dev/dokany).
